import { ArrowBackOutlined } from "@material-ui/icons";
import "./watch.scss";
import { Link, useLocation } from "react-router-dom";

export default function Watch() {
  const location=useLocation();
  console.log(location)

  const {data}=location.state
  //console.log(movie)
  //console.log(movie.video);
  // const video=movie.video
  // console.log(video);
  
  return (
    <div className="watch">
      <Link to='/'>
      <div className="back">
        <ArrowBackOutlined />
        Home
      </div>
      </Link>
      <div className="video">
        <video className="video" autoPlay progress controls src={data.video} />
      </div>
      
      {/* "https://www.kapwing.com/e/62208387f6cc090114791b22" */}
        
      
    </div>
  );
}